module vps-manager

go 1.22

require (
	github.com/pkg/sftp v1.13.6
	github.com/wailsapp/wails/v2 v2.9.2
	golang.org/x/crypto v0.21.0
)
